<?php
$server = "localhost";
$user = "sdnleuwi_sd1_user_sidang";
$password = "4X*$;?]Pc]W~";
$db_name = "sdnleuwi_sd1_db_sidang";

$conn = mysqli_connect($server, $user, $password, $db_name);

if (!$conn) {
    echo '<script>alert("Gagal Terhubung Kedatabase");</script>';
}
?>