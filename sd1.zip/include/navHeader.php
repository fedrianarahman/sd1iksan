<div class="nav-header">
    <a href="index.php" class="brand-logo" style="margin-left: 50px;">
        <img src="./images/logo-fix.png" width="100" class="ml-4" height="100" alt="">
    </a>
    <div class="nav-control">
        <div class="hamburger">
            <span class="line"></span><span class="line"></span><span class="line"></span>
        </div>
    </div>
</div>